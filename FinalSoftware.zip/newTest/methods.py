import numpy as np
import cv2


def Normalization(img):
    norm = cv2.normalize(img, None, alpha=0, beta=1, norm_type=cv2.NORM_MINMAX, dtype=cv2.CV_32F)
    norm = (255 * norm).astype(np.uint8)
    return norm


def clahe(img):
    newImg = img.copy()
    clahe = cv2.createCLAHE(clipLimit=2, tileGridSize=(3, 3))
    for i in range(3):
        newImg[:, :, i] = clahe.apply((newImg[:, :, i]))
    return newImg


def stretching(img):
    height = len(img)
    width = len(img[0])
    for k in range(0, 3):
        Max_channel = np.max(img[:, :, k])
        Min_channel = np.min(img[:, :, k])
        for i in range(height):
            for j in range(width):
                img[i, j, k] = (img[i, j, k] - Min_channel) * (255 - 0) / (Max_channel - Min_channel) + 0
    return img
