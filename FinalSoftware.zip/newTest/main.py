import cv2
import numpy as np
from methods import Normalization, stretching, clahe
import skimage.measure


ImageNum = input('Enter a number between 1 and 25 for the relative image:')
imgRGB1 = cv2.imread(ImageNum+'.png', 1)
imgRGB = cv2.resize(imgRGB1, (300, 200))


def white_balance(img):
    LABimg = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
    avgA = np.average(LABimg[:, :, 1])
    avgB = np.average(LABimg[:, :, 2])
    LABimg[:, :, 1] = LABimg[:, :, 1] - ((avgA - 128) * (LABimg[:, :, 0] / 255.0) * 1.1)
    LABimg[:, :, 2] = LABimg[:, :, 2] - ((avgB - 128) * (LABimg[:, :, 0] / 255.0) * 1.1)
    LABimg = cv2.cvtColor(LABimg, cv2.COLOR_LAB2BGR)
    return LABimg


def histEq(img):
    temp = img.copy()
    B, G, R = cv2.split(temp)
    outB = cv2.equalizeHist(B)
    outG = cv2.equalizeHist(G)
    outR = cv2.equalizeHist(R)
    res = cv2.merge((outB, outG, outR))
    return res


def gammaCorrection(img, gamma):
    y = 1 / gamma
    t = [((i / 255) ** y) * 255 for i in range(256)]
    t = np.array(t, np.uint8)

    res = cv2.LUT(img, t)
    return res


hi = histEq(imgRGB)
whiteBal = white_balance(imgRGB)
his = histEq(whiteBal)
gam = gammaCorrection(whiteBal, 0.5)

#basic Gaussian Blur using 9x9 kernel
smoothed = cv2.GaussianBlur(whiteBal, (9, 9), 10)
unsharped = cv2.addWeighted(gam, 0.5, smoothed, 0.2, 0)

fin = cv2.addWeighted(whiteBal, 0.5, unsharped, 0.5, 0)

#kernel for 2D filtering
kernel = np.array([[0, -1, 0],
                   [-1, 5, -1],
                   [0, -1, 0]])
image_sharp = cv2.filter2D(unsharped, ddepth=-1, kernel=kernel)

fin2 = cv2.addWeighted(fin, 0.5, image_sharp, 0.5, 0)
fin3 = cv2.addWeighted(fin2, 0.5, hi, 0.5, 0)

#normalization followed by fusions and finally denoised image
norm = Normalization(fin3)
str = clahe(fin3)
new = cv2.filter2D(fin3, ddepth=-1, kernel=kernel)
new1 = cv2.addWeighted(new, 0.5, fin3, 0.5, 0)
new2 = cv2.addWeighted(new1, 0.5, norm, 0.5, 0)
new3 = cv2.fastNlMeansDenoisingColored(new2, None, 3.5, 3.5, 7, 21)

cv2.imwrite('FinalImage.png', new3)

#Displaying Original image, normalized, histogram equalization fusion and final denoised image
disp = np.concatenate((imgRGB, norm, fin3, new3), axis=1)
cv2.imshow('Enhanced', disp)
cv2.waitKey(0)
cv2.destroyAllWindows()

#calculating entropy:
im1 = cv2.imread('FinalImage1.png')
im2 = cv2.imread('FinalImage2.png')
im3 = cv2.imread('FinalImage3.png')
im4 = cv2.imread('FinalImage4.png')
im5 = cv2.imread('FinalImage5.png')
ent1 = skimage.measure.shannon_entropy(im1)
ent2 = skimage.measure.shannon_entropy(im2)
ent3 = skimage.measure.shannon_entropy(im3)
ent4 = skimage.measure.shannon_entropy(im4)
ent5 = skimage.measure.shannon_entropy(im5)
avgEnt = (ent1 + ent2 + ent3 + ent4 + ent5) / 5
#print(avgEnt)
